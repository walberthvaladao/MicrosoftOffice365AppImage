#!/bin/bash

# Verifica e cria ~/.local/bin se não existir
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p "$HOME/.local/bin"
  echo "Diretório $HOME/.local/bin criado."
else
  echo "Diretório $HOME/.local/bin já existe."
fi

# Verifica e cria ~/.local/share/icons se não existir
if [ ! -d "$HOME/.local/share/icons" ]; then
  mkdir -p "$HOME/.local/share/icons"
  echo "Diretório $HOME/.local/share/icons criado."
else
  echo "Diretório $HOME/.local/share/icons já existe."
fi

# Verifica e cria ~/.local/share/applications se não existir
if [ ! -d "$HOME/.local/share/applications" ]; then
  mkdir -p "$HOME/.local/share/applications"
  echo "Diretório $HOME/.local/share/applications criado."
else
  echo "Diretório $HOME/.local/share/applications já existe."
fi

# Dando permissão de execução pros arquivos
chmod +x Microsoft_Office_365-x86_64.AppImage
chmod +x "Microsoft Office 365.desktop"

# Movendo AppImage para a pasta correta
mv Microsoft_Office_365-x86_64.AppImage $HOME/.local/bin/

# Movendo ícone para a pasta correta
mv microsoft-office-365.svg $HOME/.local/share/icons/

# Atualizando .desktop
echo "Exec=$HOME/.local/bin/Microsoft_Office_365-x86_64.AppImage" >> "Microsoft Office 365.desktop"
echo "Icon=$HOME/.local/share/icons/microsoft-office-365.svg" >> "Microsoft Office 365.desktop"

# Movendo atalho do aplicativo para a pasta correta
mv "Microsoft Office 365.desktop" $HOME/.local/share/applications

# Removendo pasta desnecessária
pasta_atual=$(pwd)
rm -rfv $pasta_atual



